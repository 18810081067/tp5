/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : add

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-05-10 15:25:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tp5
-- ----------------------------
DROP TABLE IF EXISTS `tp5`;
CREATE TABLE `tp5` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `sex` varchar(255) DEFAULT NULL COMMENT '年龄',
  `age` int(2) DEFAULT NULL COMMENT '年龄',
  `tel` varchar(11) DEFAULT NULL COMMENT '电话',
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tp5
-- ----------------------------
INSERT INTO `tp5` VALUES ('1', '郝', '男', '22', '18810081067', '.\\uploads\\20180418\\2712e485fca85650ca504ed7989798a5.jpg');
INSERT INTO `tp5` VALUES ('3', '郝', '男', '22', '18810081067', '\\uploads\\20180418\\2712e485fca85650ca504ed7989798a5.jpg');
INSERT INTO `tp5` VALUES ('4', '郝', '男', '22', '18810081067', '\\uploads\\20180418\\2712e485fca85650ca504ed7989798a5.jpg');
INSERT INTO `tp5` VALUES ('5', '郝', '男', '22', '18810081067', '\\uploads\\20180418\\2712e485fca85650ca504ed7989798a5.jpg');
