/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : add

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-05-10 14:53:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for xin_lei
-- ----------------------------
DROP TABLE IF EXISTS `xin_lei`;
CREATE TABLE `xin_lei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xin_lei
-- ----------------------------
INSERT INTO `xin_lei` VALUES ('1', '娱乐新闻');
INSERT INTO `xin_lei` VALUES ('2', '国际新闻');
INSERT INTO `xin_lei` VALUES ('3', '国内新闻');
