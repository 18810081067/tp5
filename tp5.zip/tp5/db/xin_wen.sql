/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : add

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-05-10 14:53:31
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for xin_wen
-- ----------------------------
DROP TABLE IF EXISTS `xin_wen`;
CREATE TABLE `xin_wen` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `new_title` varchar(255) DEFAULT NULL COMMENT '新闻标题',
  `cate_id` int(11) DEFAULT NULL COMMENT '新闻分类',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `news` varchar(255) DEFAULT NULL COMMENT '内容',
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xin_wen
-- ----------------------------
INSERT INTO `xin_wen` VALUES ('18', '不好玩', '1', '\\uploads\\20180510\\58c947426e770b6ba42ed3fd33567f99.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('19', '活动深V健身房', '1', '\\uploads\\20180509\\b3a37abdabec3132557c799056bae875.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('20', '活动深V健身房1', '1', '\\uploads\\20180509\\26cf0c12d13fe5f71eaa9b38bbb14ab2.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('21', '活动深V健身房', '1', '\\uploads\\20180509\\94aa7502dafc26709858caea1bd3513d.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('22', '活动深V健身房', '1', '\\uploads\\20180510\\33d4fb28a3984c50138e7101b62fe9bc.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('23', '活动深V健身房', '1', '\\uploads\\20180510\\e25de37c7cb8f9474ebf874dddde7d66.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('24', '活动深V健身房', '1', '\\uploads\\20180510\\8467a1e3461448a4fee1cae11816cec2.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('25', '活动深V健身房', '1', '\\uploads\\20180510\\592d02a763eab9d4829d48b81ac49d88.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('26', '活动深V健身房', '2', '', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('27', '活动深V健身房', '2', '', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('35', '', '1', '', '', '2018-05-10 14:02:05');
INSERT INTO `xin_wen` VALUES ('28', '活动深V健身房', '2', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('29', '活动深V健身房', '2', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('30', '活动深V健身房', '3', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('31', '活动深V健身房', '3', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('32', '活动深V健身房', '3', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('33', '活动深V健身房', '3', '\\uploads\\20180509\\afa38d53e78f87b1bf47f5f24b15262a.jpg', '    <!DOCTYPE html>  \r\n    <html>  \r\n    <head lang=\"en\">  \r\n        <meta charset=\"UTF-8\">  \r\n        <script src=\"https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js\"></script>  \r\n        <title></title>  \r\n    </head>  \r\n    <body>  \r\n    <form id=\"upl', '2018-05-09 16:00:13');
INSERT INTO `xin_wen` VALUES ('34', '45254254', '3', '\\uploads\\20180509\\ba734d5a90e6f08696aea0d2d6132b4c.jpg', '8455', '2018-05-09 16:04:34');
