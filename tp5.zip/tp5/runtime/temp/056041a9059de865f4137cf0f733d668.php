<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\1510phpe\shieryue\tp5\public/../application/index\view\index\add_user.html";i:1524056216;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo url('index/do_add_user'); ?>" method="post" enctype="multipart/form-data">
		选择图像文件：<input type="file" class="file" name="image"><br/>
		姓名 ：<input type="text" name="name" value=""><br><br>
		性别 ：男<input type="radio" name="sex" value="1" checked="checked">
			   女<input type="radio" name="sex" value="2">
			   保密<input type="radio" name="sex" value="0"><br><br>
		年龄 ：<input type="text" name="age" value=""><br><br>
		电话 ：<input type="text" name="tel" value=""><br><br>
		<input type="submit" value="确定">
		<input type="button" value="重置">
	</form>
</body>
</html>