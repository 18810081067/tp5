<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\1510phpe\shieryue\tp5\public/../application/index\view\xinwen\news_content.html";i:1525853325;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>文章发布</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/index.css">
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/home/images/logo1.png" alt="logo"/>
<ul>
	<li><a href="<?php echo url('xinwen/register'); ?>">会员注册</a>/</li>
    <li><a href="<?php echo url('xinwen/login'); ?>">登陆</a></li>
</ul>
</div>

<div id="nav">
<ul>
    <li ><a href="<?php echo url('xinwen/index'); ?>"  class="active">首页</a></li>
    <?php if(is_array($lei) || $lei instanceof \think\Collection || $lei instanceof \think\Paginator): $i = 0; $__LIST__ = $lei;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <li><a href="<?php echo url('xinwen/index_cha',['id' => $v['id']]); ?>"><?php echo $v['news_title']; ?></a></li>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>

<div class="blank20"></div>

<div class="article">
<h3><?php echo $info['new_title']; ?></h3>
<p><?php echo $info['new_title']; ?></p>
<p><?php echo $info['news']; ?></p>


</div>
</div>

<div class="blank20"></div>

<div id="footer">
	<p>版权所有&copy;<br />联系方式：010-82157081&nbsp;&nbsp;010-82157081&nbsp;&nbsp;010-82157081</p>
</div>

</body>
</html>
