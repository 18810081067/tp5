<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\1510phpe\shieryue\tp5\public/../application/admin\view\index\cate_add.html";i:1525759972;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/admin/css/public.css">
</head>

<body>
<div  id="main">
<h2>添加分类</h2>
	<table border="0"    cellspacing="10" cellpadding="0">
		  <tr>
			<td>分类名称：</td>
			<td><input   type="text" name="news_title" class="txt"/><span class="error">您添加的名称已经存在</span></td>
		  </tr>
		  <tr>
			<td>&nbsp;</td>
			<td><input  type="submit" value="添 加"  class="sub" id="ti"/><input  type="reset" value="重 置"  class="res"/></td>
		  </tr>
	</table>
</div>
</body>
</html>
<script src="/shieryue/tp5/public/static/jquery-1.12.0.min.js"></script>
<script>
   $("#ti").click(function(){
    var news_title=$("input[name='news_title']").val();
    $.ajax({
      url:"<?php echo url('xinwen/cate_add'); ?>",
      type:'post',
      data:{'news_title':news_title},
      dataType:'json',
      success:function(msg){
        if(msg.ok==1){
        	alert(msg.ms);
        	location.href="<?php echo url('xinwen/cate_add'); ?>";
        }else{
        	alert(msg.ms);
        	return;
        }
      
      }
    })
  })
</script>
