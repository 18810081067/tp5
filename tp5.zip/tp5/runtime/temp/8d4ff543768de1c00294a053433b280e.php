<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\1510phpe\shieryue\tp5\public/../application/admin\view\index\news_add.html";i:1525852722;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理员新闻添加</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/admin/css/public.css">
</head>

<body>
<meta charset='utf8'/>
<div  id="main">
<h2>添加新闻</h2>
<form id="tijiao">
<table border="0"    cellspacing="10" cellpadding="0">
  <tr>
    <td>新闻标题：</td>
    <td><input   type="text" name="new_title" class="txt"/ id="news_title"><span class="error">不得超过20个字符</span></td>
  </tr>
  <tr>
    <td>新闻分类：</td>
    <td>
    <select class="s1" name='cate_id'>
      <?php if(is_array($xinlei) || $xinlei instanceof \think\Collection || $xinlei instanceof \think\Paginator): $i = 0; $__LIST__ = $xinlei;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
      		<option value="<?php echo $vo['id']; ?>"><?php echo $vo['news_title']; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
  <span class="error">验证必须有效分类（必须是数据表存的分类）</span>
	</td>
  </tr>
  <tr>
    <td>图片上传：</td><input type="hidden" id="kk" name="image" value="" />
    <td><input id="file_tag" type="file" name="file"/></td>
  </tr>
  <tr>
    <td>新闻内容：</td>
    <td><textarea  name="news" class="textarea"></textarea><span class="error">必须超过100字</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input  type="submit" value="添 加"  class="sub" id="ti" /><input  type="reset" value="重 置"  class="res"/></td>
  </tr>
</table></form>
</div>
</body>
</html>
<script src="/shieryue/tp5/public/static/jquery-1.12.0.min.js"></script>


<script>
   $("#ti").click(function(){
    // var new_title=$("input[name='new_title']").val();
    // var cate_id=$("select[name='cate_id']").val();
    // var news=$("textarea[name='news']").val();
    // var news=$("textarea[name='news']").val();
    var tijiao=$("#tijiao").serialize(); //将用作提交的表单元素的值编译成字符串 所有
     //console.log(tijiao);
   // datakia() //文件
     $.ajax({
      url:"<?php echo url('xinwen/news_add'); ?>",
      type:'post',
      data:tijiao,
      dataType:'json',
      success:function(msg){
        if(msg.ok==0){
          alert(msg.ms);
          return;
        }else{
          console.log(msg)
        }
      }
      })
  
  })

 
   $("#file_tag").change(function(){


      var file = $('#file_tag')[0].files[0];
      var form = new FormData();//创建一个form对象
            form.append('file_name', file);//文件名称    
     //from.append("UploadFiles[file]",form);
    //console.log(form)
    $.ajax({
      url:"<?php echo url('xinwen/tu'); ?>",
      type:'post',
      data:form,
      //dataType:'json',
      contentType: false,
      processData: false,
      success:function(msg){
        //console.log(msg)
        if(msg){
          $("#kk").val(msg);
        }
        
      }
      })
 }) 
  
</script>
