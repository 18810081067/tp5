<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"D:\1510phpe\shieryue\tp5\public/../application/index\view\xinwen\index_list.html";i:1525936011;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>国内新闻</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/index.css">
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/home/images/logo1.png" alt="logo"/>
<ul>
<li style="color:red"><b><?php echo (\think\Session::get('user_name')) ? \think\Session::get('user_name') :  'xxx未登录'; ?><?php echo (\think\Session::get('addtime')) ? \think\Session::get('addtime') :  ''; ?></b></li>
	<li><a href="<?php echo url('xinwen/register'); ?>">会员注册</a>/</li>
    <li><a href="<?php echo url('xinwen/login'); ?>">登陆</a></li>
</ul>
</div>

<div id="nav">
<ul>
    <li ><a href="<?php echo url('xinwen/index'); ?>"  class="active">首页</a></li>
    <?php if(is_array($lei) || $lei instanceof \think\Collection || $lei instanceof \think\Paginator): $i = 0; $__LIST__ = $lei;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <li><a href="<?php echo url('xinwen/index_cha',['id' => $v['id']]); ?>"><?php echo $v['news_title']; ?></a></li>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>

<div class="blank20"></div>

<div id="main1">
	<div class="title"><h3><?php echo $inf['news_title']; ?></h3><a href="#">更多&gt;&gt;</a></div>
    <ul>
        <?php if(is_array($info) || $info instanceof \think\Collection || $info instanceof \think\Paginator): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        	<li data-id="<?php echo $v['id']; ?>"><img class="edit_img" src="/shieryue/tp5/public/<?php echo $v['image']; ?>"  height="100" width="100" value="" /><input type="file"  name="file"  id="edit_file_input" style="display: none;" /><p><a href="<?php echo url('xinwen/index_xiang',['id' => $v['id']]); ?>"><?php echo $inf['news_title']; ?></a></p></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
<script src="/shieryue/tp5/public/static/jquery-1.12.0.min.js"></script>
<script>
var data_id;
var img_obj;
$(document).on('click','.edit_img',function  () {
    // alert(1);
    $("#edit_file_input").trigger('click')
    data_id = $(this).parents('li').data('id');
    img_obj = $(this);
    // alert(id);

    // alert(data_id)
})


$("#edit_file_input").change(function(){
      var file = $(this)[0].files[0];
      var form = new FormData();//创建一个form对象
            form.append('file_name', file);//文件名称    
            form.append('id', data_id );
     //from.append("UploadFiles[file]",form);
    //console.log(form)
    $.ajax({
      url:"<?php echo url('xinwen/tu'); ?>",
      type:'post',
      data:form,
      //dataType:'json',
      contentType: false,
      processData: false,
      success:function(msg){
        //console.log(msg)
        if(msg){
            var a='/shieryue/tp5/public/'+msg;
            // alert(a);
            img_obj.attr('src',a);
        }
        
      }
      })
 }) 
 </script>  
</div>

<div class="blank20"></div>

<div class="news">
	<div class="title"><h3>分类新闻列表</h3><a href="#">更多&gt;&gt;</a></div>
    <?php if(is_array($info) || $info instanceof \think\Collection || $info instanceof \think\Paginator): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <ul class="width">
        	<li><span><?php echo $v['time']; ?></span><a  href="<?php echo url('xinwen/index_xiang',['id' => $v['id']]); ?>"><?php echo $v['new_title']; ?></a></li>
        </ul>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<center>当前页：1&nbsp;<a>首页</a>&nbsp;<a>下一页</a>&nbsp;<a>上一页</a>&nbsp;<a>尾页</a>&nbsp;共20页</center> 
<div class="blank20"></div>

<div id="footer">
	<p>版权所有&copy;<br />联系方式：010-82157081&nbsp;&nbsp;010-82157081&nbsp;&nbsp;010-82157081</p>
</div>

</body>
</html>
