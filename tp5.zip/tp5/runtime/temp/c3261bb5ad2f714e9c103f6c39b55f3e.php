<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"D:\1510phpe\shieryue\tp5\public/../application/admin\view\index\news_list.html";i:1525856017;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/admin/css/public.css">
</head>

<body>
<meta charset='utf8'/>
<div  id="main">
<table width="90%" border="0" cellspacing="0" cellpadding="0" class="news_table">
  <caption>
    新闻列表
  </caption>
  <tr>
    <th scope="col">编号</th>
    <th scope="col" width="100">新闻标题</th>
    <th scope="col">所属分类</th>
    <th scope="col" width="200">新闻内容</th>
    <th scope="col">添加人</th>
    <th scope="col">时间</th>
    <th scope="col">操作</th>
  </tr>
{volist name="lei" id="v"}
  <tr>
		<td><?php echo $v['id']; ?></td>
		<td><?php echo $v['new_title']; ?></td>
		<td><?php echo $v['news_title']; ?></td>
		<td><?php echo $v['news']; ?></td>
		<td>丽丽</td>
		<td><?php echo $v['time']; ?></td>
		<td><a href="">删除</a>||<a href="">修改</a></td>
  </tr>
 {volist}
</table>
<center>当前页：1&nbsp;&nbsp;&nbsp;<a>首页</a>&nbsp;&nbsp;&nbsp;<a>下一页</a>&nbsp;&nbsp;&nbsp;<a>上一页</a>&nbsp;&nbsp;&nbsp;<a>尾页</a>&nbsp;&nbsp;&nbsp;共20页</center>
</div>
</body>
</html>
