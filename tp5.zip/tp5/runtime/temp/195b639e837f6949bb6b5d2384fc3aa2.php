<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"D:\1510phpe\shieryue\tp5\public/../application/index\view\index\edit_user.html";i:1524050230;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo url('index/do_edit_user'); ?>" method="post">
		姓名 ：<input type="text" name="name" value="<?php echo $info['name']; ?>"><br><br>
		性别 ：
			<?php if($info['sex'] == '1'): ?>
			男<input type="radio" name="sex" value="1" checked="checked">
			女<input type="radio" name="sex" value="2">
			保密<input type="radio" name="sex" value="0"><br><br>
			<?php elseif($info['sex'] == '2'): ?>
			男<input type="radio" name="sex" value="1">
			女<input type="radio" name="sex" value="2" checked="checked">
			保密<input type="radio" name="sex" value="0"><br><br>
			<?php else: ?>
			男<input type="radio" name="sex" value="1">
			女<input type="radio" name="sex" value="2">
			保密<input type="radio" name="sex" value="0" checked="checked"><br><br>
			<?php endif; ?>
		年龄 ：<input type="text" name="age" value="<?php echo $info['age']; ?>"><br><br>
		电话 ：<input type="text" name="tel" value="<?php echo $info['tel']; ?>"><br><br>
		<input type="hidden" value="<?php echo $info['id']; ?>" name="id">
		<input type="submit" value="确定">
		<input type="button" value="取消">
	</form>
</body>
</html>