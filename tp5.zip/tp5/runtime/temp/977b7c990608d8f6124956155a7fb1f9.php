<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"D:\1510phpe\shieryue\tp5.0\public/../application/admin\view\index\admin.html";i:1525759783;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<frameset rows="92,*"   border="0"  frameborder="0">
	<frame src="<?php echo url('admin/top'); ?>" />
    <frameset cols="240,*">
    	<frame src="<?php echo url('admin/left'); ?>" />
        <frame src="<?php echo url('xinwen/news_add'); ?>" name="right" />
    </frameset>
</frameset>
</html>
