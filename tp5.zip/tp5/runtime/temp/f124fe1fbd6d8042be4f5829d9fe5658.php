<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\1510phpe\shieryue\tp5\public/../application/admin\view\index\cai.html";i:1525935102;}*/ ?>
<ul>
    <li><a href="<?php echo url('xinwen/cai_zhi'); ?>"  target="right">智联</a></li><br>
    	<li><a href="<?php echo url('xinwen/cai_boss'); ?>"  target="right">boss直聘</a></li><br>
        <li><a href="<?php echo url('xinwen/cai_ying'); ?>"  target="right">幕课</a></li><br>
        <li><a href="<?php echo url('xinwen/cai_css'); ?>"  target="right">sf.gg论坛</a></li><br>
</ul>

