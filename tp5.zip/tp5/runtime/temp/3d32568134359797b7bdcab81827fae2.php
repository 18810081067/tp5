<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"D:\1510phpe\shiyi\tp5\public/../application/index\view\index\user.html";i:1524057240;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<style>
	.layui-laypage-curr em {margin-right: 10px;font-style: normal;}
	a{margin-right: 10px;}
</style>
<body>
<h4>用户信息管理</h4>
<a href="<?php echo url('index/add_user'); ?>">添加</a>
<table border="1" cellpadding="5" cellspacing="0">
	<tr>
		<td>ID</td>
		<td>头像</td>
		<td>姓名</td>
		<td>性别</td>
		<td>年龄</td>
		<td>电话</td>
		<td>操作</td>
	</tr>
	<?php if(is_array($data_list) || $data_list instanceof \think\Collection || $data_list instanceof \think\Paginator): $i = 0; $__LIST__ = $data_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
		<tr>
			<td><?php echo $vo['id']; ?></td>
			<td><img src="/shiyi/tp5/public/<?php echo $vo['img']; ?>" alt="" width="50";height="50"></td>
			<td><?php echo $vo['name']; ?></td>
			<td><?php if($vo['sex'] == '1'): ?>男<?php elseif($vo['sex'] == '2'): ?>女<?php else: ?>保密<?php endif; ?></td>
			<td><?php echo $vo['age']; ?></td>
			<td><?php echo $vo['tel']; ?></td>
			<td><a href="<?php echo url('index/edit_user',['id' => $vo['id']]); ?>">编辑</a> | <a href="<?php echo url('index/del',['id' => $vo['id']]); ?>">删除</a></td>
		</tr>
	<?php endforeach; endif; else: echo "" ;endif; ?>


</table>
<div><?php echo $page; ?></div>


</body>
</html>