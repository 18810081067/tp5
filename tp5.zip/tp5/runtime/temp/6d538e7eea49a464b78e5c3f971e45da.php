<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\1510phpe\shieryue\tp5\public/../application/index\view\xinwen\index.html";i:1525935366;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>前台首页</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/index.css">
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/home/images/logo1.png" alt="logo"/>
<ul>
<li style="color:red"><b><?php echo (\think\Session::get('user_name')) ? \think\Session::get('user_name') :  'xxx未登录'; ?><?php echo (\think\Session::get('addtime')) ? \think\Session::get('addtime') :  ''; ?></b></li>
	<li><a href="<?php echo url('xinwen/register'); ?>">会员注册</a>/</li>
    <li><a href="<?php echo url('xinwen/login'); ?>">登陆</a></li>
</ul>
</div>
新闻搜搜<br> <input type="text" name="spech"  /><input type="button" class="spech" value="新闻搜索" style="background-color:blue"/>
<div id="nav">
 
<ul>
	<li ><a href="<?php echo url('xinwen/index'); ?>"  class="active">首页</a></li>
    <?php if(is_array($lei) || $lei instanceof \think\Collection || $lei instanceof \think\Paginator): $i = 0; $__LIST__ = $lei;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <li><a href="<?php echo url('xinwen/index_cha',['id' => $v['id']]); ?>"><?php echo $v['news_title']; ?></a></li>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>

<div class="blank20"></div>

<div class="news">
	<div class="title"><h3>最新新闻</h3><a href="#">更多&gt;&gt;</a></div>
<span id='kai'>
    <?php if(is_array($wen) || $wen instanceof \think\Collection || $wen instanceof \think\Paginator): $i = 0; $__LIST__ = $wen;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
         <ul>
        	<li><?php echo $v['time']; ?><a  href="<?php echo url('xinwen/index_xiang',['id' => $v['id']]); ?>"><?php echo $v['new_title']; ?></a></li>
          <li><span class="jiu" style="cursor:pointer"><?php echo $v['new_title']; ?></span><input type="text" class="xin" id="<?php echo $v['id']; ?>" style="display:none"></li>
        </ul>
    <?php endforeach; endif; else: echo "" ;endif; ?>    
</span>
</div>
<center>  
<div class="page" pagenow="1" pagesum="<?php echo $pagesum; ?>">
  <a href="javascript:void(0)" class="first">首页</a>
  <a href="javascript:void(0)" class="prev">上一页</a>
  <a href="javascript:void(0)" class="next">下一页</a>
  <a href="javascript:void(0)" class="last">尾页</a>
  <input type="text" value="<?php echo $p; ?>/<?php echo $pagesum; ?>" class="next">共<?php echo $count; ?>条数据
</div></center>
<div class="blank20"></div>

<div id="footer">
	<p>版权所有&copy;<br />联系方式：010-82157081&nbsp;&nbsp;010-82157081&nbsp;&nbsp;010-82157081</p>
</div>

</body>
</html>
<script src="/shieryue/tp5/public/static/jquery-1.12.0.min.js"></script>
<script>
 $(document).on("click",".jiu",function(){
    //alert(123);
    var name=$(this).html();
    $(this).next().show();
    $(this).next().val(name);
    $(this).hide();
    $(this).next().show();
    $(this).next().focus();
  })
  $(document).on("blur",".xin",function(){
    //alert(123);
    var a=$(this);
    var name=a.val();
    var id=a.attr("id");
    // alert(id);
    $.ajax({
        type:"post",
        data:{
          "name":name,
          "id":id
        },
        url:"<?php echo url('xinwen/con'); ?>",
        //dataType:"json",
        success:function(res){
          a.prev().html(name);
          a.val(name);
          a.hide();
          a.prev().show();
        }
    })
        

  })
$(document).on("click",".del",function(){
  var id=$(this).attr("id");
  alert(id);


})
$(document).on("click","input[type='button']",function(){
    var spech=$("input[name='spech']").val();
    $.post("<?php echo url('xinwen/spech'); ?>",{"spech":spech},function(data){
      if(data.ok==0){
        alert('搜索失败');
      }else{
        alert('成功');
        var shu="";
        var content=data.content;
        $.each(content,function(k,v){
          
          shu+="<ul>";
            shu+="<li><span>"+v.time+"</span><a  href=''>"+v.new_title+"</a></li>";
          shu+="</ul>";
        })
        $(".page").attr("pagesum",data.pagesum);
        //alert(shu)
        $("#kai").html(shu);
      }
    },'json')
  })

$(document).on("click",".page a",function(){
  var spech=$("input[name=spech]").val();
  var pagenow=parseInt($(this).parent().attr("pagenow"));
  var pagesum=parseInt($(this).parent().attr("pagesum"));
  if($(this).is(".first")){
    var p=1;
  }else if($(this).is(".prev")){
    var p=pagenow-1;
  }else if($(this).is(".next")){
    var p=pagenow+1;
  }else if($(this).is(".last")){
    var p=pagesum;
  }else if(p<=0||p>pagesum){
    return;
  }
  //alert(p);return;
  $.post("<?php echo url('xinwen/page'); ?>",{"spech":spech,"p":p},function(data){
    if(data.ok==0){
      alert('没有分页值');
    }else{
      //alert('成功');
      var content=data.content;
      var shu="";
      $.each(content,function(k,v){
        shu+="<ul>";
            shu+="<li><span>"+v.time+"</span><a  href=''>"+v.new_title+"</a></li>";
          shu+="</ul>";
      })
      $(".page").attr("pagenow",p);
      $(".page").attr("pagesum",data.pagesum);
      $(".next").attr("value",data.p+'/'+data.pagesum);
      $(".next").attr("value",data.p+'/'+data.pagesum);
      $("#kai").html(shu);
    }
  },'json')
})
</script>