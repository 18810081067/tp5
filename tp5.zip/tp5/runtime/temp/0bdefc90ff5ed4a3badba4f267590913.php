<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"D:\1510phpe\shieryue\tp5\public/../application/index\view\xinwen\register.html";i:1525749688;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>前台首页</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/index.css">
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/public.css">
<style>
#header{ height:92px; background:none;}
#main  h2{ margin-left:0px; line-height:50px; font-size:20px;}
.article{margin-left:-50px;}

a{color:#087eac;}
.error{color: red}
</style>
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/home/images/logo1.png" alt="logo"/>
<ul>
    <li><a href="<?php echo url('xinwen/register'); ?>">会员注册</a>/</li>
    <li><a href="<?php echo url('xinwen/login'); ?>">登陆</a></li>
</ul>
</div>

<div id="nav">
<ul>
	<li ><a href="#"  class="active">首页</a></li>
    <li><a href="#">国内新闻</a></li>
    <li><a href="#">国际新闻</a></li>
    <li><a href="#">军事新闻</a></li>
    <li><a href="#">娱乐新闻</a></li>
</ul>
</div>
<div>
<div  id="main">
<h2 align="center">欢迎注册新用户</h2>
<div class="article">

<form name="login"  action="" method="post">

<table border="0"    cellspacing="20" cellpadding="0" align="center">
  <tr>
    <td>用户名：</td>
    <td><input   type="text" name="username" class="txt" width="2"/><span class="error">用户名由6-18位的字母数字下划线组成，不能由数字开头</span></td>
  </tr>
  <tr>
    <td>密码：</td>
    <td><input  type="password" name="psd"  class="txt"/><span class="error">密码长度不能少于六位</span></td>
  </tr>
  <tr>
    <td>重复密码：</td>
    <td><input  type="password" name="psd"  class="txt"/><span class="error">密码长度不能少于六位，两次密码必须相同</span></td>
  </tr>
  <tr>
    <td>手机号：</td>
    <td><input  type="text" name="mobile"  class="txt"/><span class="error">验证手机号:11位  13 15 18开头</span></td>
  </tr>
  <tr>
    <td>邮箱：</td>
    <td><input  type="text" name="email"  class="txt"/><span class="error">匹配一个后缀名可能是.com|.net|.cn|.edu</span></td>
  </tr>
  <tr>
    <td>身份证：</td>
    <td><input  type="text" name="card"  class="txt"/><span class="error">验证身份证号  18位或者17位加一个X</span></td>
  </tr>
  <tr>
    <td>性别：</td>
    <td>
    <input   type="radio"  name="sex"  checked="checked"/>男&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input   type="radio"  name="sex" />女</td>
  </tr>
    <tr>
    <td>爱好：</td>
    <td>
    <input   type="checkbox" name="web"/>&nbsp;上网&nbsp;&nbsp;
    <input   type="checkbox" name="sport"/>&nbsp;体育&nbsp;&nbsp;
    <input   type="checkbox"  name="study"/>&nbsp;学习&nbsp;&nbsp;
    </td>
  </tr>
      <tr>
    <td>城市：</td>
    <td>
    <select name="city"  class="s1">
    	<option value="1">北京</option>
        <option value="2">上海</option>
        <option value="3">南京</option>
    </select>
    </td>
  </tr>
	<tr>
		<td>介绍：</td><td><textarea cols=25 rows=5></textarea><span class="error">不能多于200个字符</span></td>
	</tr>
  <tr>
    <td>&nbsp;</td>
    <td><input  type="submit" value="添 加"  class="sub"/><input  type="reset" value="重 置"  class="res"/></td>
  </tr>
</table>

</form>

</div>
</div>


<div class="blank20"></div>

<div id="footer">
	<p>版权所有&copy;<br />联系方式：010-82157081&nbsp;&nbsp;010-82157081&nbsp;&nbsp;010-82157081</p>
</div>

</body>
</html>
