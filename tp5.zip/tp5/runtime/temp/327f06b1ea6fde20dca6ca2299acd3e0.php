<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\1510phpe\shieryue\tp5\public/../application/admin\view\index\top.html";i:1525752079;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>顶部</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/admin/css/public.css">
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/admin/images/logo1.png" />
<h3>欢迎<font style="color:red">****</font>登陆</h3>
<h3><span id="time"></span></h3><a href="">退出</a>
</div>
</body>
</html>
<script>
  function show(){
    var date=new Date();
    var a=date.toLocaleString();
    document.getElementById('time').innerHTML=a;
  }
setInterval('show()',1000);

</script>

