<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\1510phpe\shieryue\tp5\public/../application/index\view\xinwen\login.html";i:1525924090;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>前台首页</title>
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/index.css">
<link rel="stylesheet" type="text/css" href="/shieryue/tp5/public/static/home/css/public.css">
<style>
#header{ height:92px; background:none;}
#main  h2{ margin-left:0px; line-height:50px; font-size:20px;}
.article{margin-left:-50px;}
h2{margin-left:50px}

</style>
</head>

<body>
<div id="header">
<img src="/shieryue/tp5/public/static/home/images/logo1.png" alt="logo"/>
<ul>
    <li><a href="<?php echo url('xinwen/register'); ?>">会员注册</a></li>
    <li><a href="<?php echo url('xinwen/login'); ?>">登陆</a></li>
</ul>
</div>

<div id="nav">
<ul>
	 <li ><a href="<?php echo url('xinwen/index'); ?>"  class="active">首页</a></li>
    <?php if(is_array($lei) || $lei instanceof \think\Collection || $lei instanceof \think\Paginator): $i = 0; $__LIST__ = $lei;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <li><a href="<?php echo url('xinwen/index_cha',['id' => $v['id']]); ?>"><?php echo $v['news_title']; ?></a></li>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</ul>
</div>
<div>
<div  id="main">
<h2 align="center">欢迎登录</h2>
<div class="article">

<table border="0"    cellspacing="20" cellpadding="0" align="center">
  <tr>
    <td>用户名：</td>
    <td><input   type="text" name="username" class="txt" width="2"/><span class="error">用户名不存在</span></td>
  </tr>
  <tr>
    <td>密码：</td>
    <td><input  type="password" name="pwd"  class="txt"/><span class="error">密码错误</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input  type="submit" value="登 录"  class="sub" id="ti"/><input  type="reset" value="重 置"  class="res"/></td>
  </tr>
</table>

</div>
</div>


<div class="blank20"></div>

<div id="footer">
	<p>版权所有&copy;<br />联系方式：010-82157081&nbsp;&nbsp;010-82157081&nbsp;&nbsp;010-82157081</p>
</div>

</body>
</html>   
<script src="/shieryue/tp5/public/static/jquery-1.12.0.min.js"></script>
<script>
   $("#ti").click(function(){
    var username=$("input[name='username']").val();
    var pwd=$("input[name='pwd']").val();
    $.ajax({
      url:"<?php echo url('xinwen/login'); ?>",
      type:'post',
      data:{'username':username,'pwd':pwd},
      //dataType:'json',
      success:function(msg){
        if(msg){
          alert('跳转');
          location.href="<?php echo url('xinwen/index'); ?>";
        }else{
          //console.log(msg)
          alert('没有该用户');
          return;
        }
      
      }
    })
  })
</script>

