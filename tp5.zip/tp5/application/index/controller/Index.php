<?php
namespace app\index\controller;
use think\Controller;
use think\Model;
use think\Db;
header("Content-type:text/html;charset=UTF-8");
class Index extends Controller
{
	  public function _empty($name)
    {
        echo $name.'这个操作不存在';
    }

    public function index()
    {
    	
       	$result = Db::table('tp5')->paginate(5);
		// 获取分页显示
		$page = $result->render();
		//dump($result);die;
		//var_dump($result);die;
		// 模板变量赋值
		$this->assign('data_list', $result);
		$this->assign('page', $page);
		//return $this->success('展示成功');
		return $this->fetch('user');
         //return view('user',['data_list'=>$result]);
    }

    public function add_user()
    {
    	return view('add_user');
    }
    public function do_add_user()
    {
    	if(request()->isPost()){
    		//文件上传两种方式
	    	$data = input('post.');
	    	//$file =$_FILES['image'];
	    	$file = request()->file('image');
	    	$info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
	    	$path = DS . 'uploads' . DS . $info->getSaveName();
	    	// echo $data;
	    	// die;
	    	$data=['name'=>$data['name'],'sex'=>$data['sex'],'age'=>$data['age'],'tel'=>$data['tel'],'img'=>$path];
	    	$add_res = Db::name('tp5')->insert($data);
    		if($add_res){
    			$this->success('新增成功', 'Index/index');
    			// return $this->success('新增成功');
    		}else{
    			return $this->error('添加失败！');
    		}
    	}
    }
    public function edit_user(){
    	if(request()->isGet()){
    		$id = input('id');
    		$info = Db::table('tp5')->where('id',$id)->find();
    		// dump($info);die;
    		return $this->fetch('edit_user',array('info'=>$info));
    	}
    }
    public function do_edit_user()
    {	
    	if(request()->isPost()){
    		$data['name'] = input('name');
    		$data['sex'] = input('sex');
    		$data['age'] = input('age');
    		$data['tel'] = input('tel');
    		$res = Db::table('tp5')->where('id',input('post.id'))->update($data);
    		// echo db('tp5')->getlastsql();die;
    		if($res){
    			$this->success('更新成功','index');
    		}else{
    			$this->error('更新失败！');
    		}
    	}
    }
    public function del(){
    	if(request()->isGet()){
    		$del_id = input('id');
    		$res = Db::table('tp5')->where('id',$del_id)->delete();
    		if($res){
    			$this->success('删除成功！','index');
    		}else{
    			$this->error('删除失败！');
    		}
    	}
    }
}