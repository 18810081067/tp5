<?php
namespace app\index\controller;
use think\Controller;
use think\Model;
use think\Db;
use think\Session;
header("Content-type:text/html;charset=UTF-8");
class Xinwen extends Controller
{

/*
*@作者 郝龙祥 
*@内容 新闻模板
*@参数 前台 模板
*@时间 2018-5-8
*/ 
	/*-----前台首页---------*/
    public function index()
    {
        $lei=$this->lie();
        $wen=$this->xin();
        $count=Db::table('xin_wen')->count();
        $pagesum=ceil($count/4);
        return $this->fetch('xinwen/index',['lei'=>$lei,'wen'=>$wen,'pagesum'=>$pagesum,'count'=>$count,'p'=>1]);
    }
    //分类所有
    public function lie(){

        $lei=Db::table('xin_lei')->select(); 
        return $lei;
    }
    //新闻所有
     public function xin(){
        $wen=Db::table('xin_wen')->limit(4)->select(); 
        return $wen;
    }
    //详情所有
    public function xiang(){
        $id = input('id');
        $info = Db::table('xin_wen')->where('cate_id',$id)->select();
        //$info = Db::query("");
        return $info;   
    }
     public function ah(){
        $id = input('id');
        $inf = Db::table('xin_lei')->where('id',$id)->find();
        //$info = Db::query("");
        return $inf;   
    }
    //详情单个
    public function xiang_all(){
        $id = input('id');
        $info = Db::table('xin_wen')->where('id',$id)->find();
        return $info;   
    }
    //新闻分类详情
    public function index_cha()
    {
       if(request()->isGet()){ 
            $info=$this->xiang();
            $inf=$this->ah();
           // print_r($inf);die;
            $lei=$this->lie();
            return $this->fetch('xinwen/index_list',['info'=>$info,'lei'=>$lei,'inf'=>$inf]);
        }else{
             return $this->fetch('xinwen/index');
        }
    }

    //ajax 文件上传即点即改
    public function tu(){
        $file = request()->file('file_name');
        $id=input('id');
        // echo "<pre>";
        //     print_r($id);die;
        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
        $path = DS . 'uploads' . DS . $info->getSaveName();//路径
        //echo  json_encode($path);
        //$id=input('id');
        $data=['image'=>$path];
        $res = Db::table('xin_wen')->where('id',$id)->update($data);
        return $path;
    }

    //新闻信息即点即改修改
   public function con(){     
        $id=input('id');
        $name=input('name');
        $data=['new_title'=>$name];
        Db::table('xin_wen')->where('id',$id)->update($data);            
    }

    //单个新闻标题详情
    public function index_xiang(){
       if(request()->isGet()){ 
            $info=$this->xiang_all();
            $lei=$this->lie();
            return $this->fetch('xinwen/news_content',['info'=>$info,'lei'=>$lei]);
        }else{
          $this->error("对不起，您没有此权限，请联系管理员！");
        } 
    }

    //ajax搜索
    public function spech(){
        if(request()->isPost()){ 
            $us=input('spech');
            $spech=isset($us)?$us:'';
                if($spech!=""){
                     $map['new_title']=array("like","$spech%");
                    }else{
                        $map['new_title']=array("like","$spech%");
                    }

                    $list=Db::table('xin_wen')->where($map)->limit(4)->select();
                    //var_dump($list);die;
                    $count=Db::table('xin_wen')->where($map)->count();
                    $pagesum=ceil($count/4);
                    if($list){
                        $data['ok']=1;
                        $data['content']=$list;
                        $data['pagesum']=$pagesum;
                    }else{
                        $data['ok']=0;
                    }
                    echo  json_encode($data);
               //$this->ajaxReturn($data);    
             }else{
                $this->error("对不起，您没有此权限，请联系管理员！");
             }
    }
    //ajax分页
    public function page(){
        if(request()->isPost()){ 
            $spech=input('spech');
            $p=input('p');
            if($p==0){
                $data['ok']=0;
                 echo  json_encode($data);die;
            }
        if($spech!=""){
            $map['new_title']=array("like","$spech%");
        }else{
            $map['new_title']=array("like","$spech%");
        }
        $state=($p-1)*4;
        $list=Db::table('xin_wen')->limit($state,4)->where($map)->select();
        //var_dump($list);die;
        $count=Db::table('xin_wen')->where($map)->count();
        $pagesum=ceil($count/4);
        //$con=$p*4;
        if($list){
            $data['ok']=1;
            $data['content']=$list;
            $data['pagesum']=$pagesum;
            $data['p']=$p;
           // $data['con']=$con;
        }else{
            $data['ok']=0;
        }
       echo  json_encode($data);
    
    }else{
             $this->error("对不起，您没有此权限，请联系管理员！");
        }
    }
    /*-----前台登录---------*/
    public function login()
    {
        if(request()->isPost()){ //ajax接值
          $data = input('post.');
          $data=['username'=>$data['username'],'pwd'=>$data['pwd']];//名称密码
          $us='/^1[357]\d{9}$/'; //用户  13,15,17开头 11位
         // if(preg_match($us,$data['username'])){
               $res = Db::table('xin_user')->where($data)->find();//查询数据库
          cookie("user_id",$res['id']);
          cookie("user_name",$res['username'],7*24*3600);

          Session::set("user_name",$res['username']);   //session
          Session::set("addtime",$res['addtime']);   //session
          $date =['addtime'=>date('Y-m-d H:i:s',time())];//登录时间

          $arr=Db::table('xin_user')->where('id',$res['id'])->update($date);//修改管理员登录时间
         // echo Db::table('xin_user')->getLastSql();die;
         
          return $res;
        }else{
            $lei=$this->lie();
    		return $this->fetch('xinwen/login',['lei'=>$lei]);
        }
    }

 public function ju(){
        //parent::__construct();
        //判断用户是否登录
        $session=cookie('user_name');
        if(empty($session)){
            $this->success('管理员未登录,请先登录','xinwen/login');
        }
        
    }
    /*-----前台注册---------*/
    public function register()
    {
        $lei=$this->lie();
		return $this->fetch('xinwen/register',['lei'=>$lei]);
    }

    /*-----前台新闻分类---------*/
    public function index_list()
    {
		return $this->fetch('xinwen/index_list');
    }

    /*-----前台新闻详情---------*/
    public function news_content()
    {
		return $this->fetch('xinwen/news_content');
    }


}