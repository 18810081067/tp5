<?php
namespace app\admin\controller;
use think\Controller;
use think\Model;
use think\Db;
header("Content-type:text/html;charset=UTF-8");
class Xinwen extends Controller
{

/*
*@作者 郝龙祥 
*@内容 新闻模板
*@参数 后台 模板
*@时间 2018-5-8
*/ 
/*
@param 2018-5-9
 */
// const succcess_code = 0; //全局状态  
// const error_code = 1;
// array_column   取某一列
// array_flip  值变键
// array_keys 取出键值
// & 取地址符
// 拼数据
// self::error_code //调用

    /*-----新闻添加---------*/
    public function news_add()
    {
    	if(request()->isPost()){ 
    		$us=input('post.');

    		//$file = request()->file('file_name');
// echo "<pre>";
//     		print_r($us);die;
	    	if($us){ //文件上传 规则
					// $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
			  //   	$path = DS . 'uploads' . DS . $info->getSaveName();
			    	$time=date('Y-m-d H:i:s',time());
			    	$data=['new_title'=>input('new_title'),'cate_id'=>input('cate_id'),'image'=>input('image'),'news'=>input('news'),'time'=>$time];
         //            echo "<pre>";
         // print_r($data);die;
			    	$add_res = Db::name('xin_wen')->insert($data);
			    	if($add_res){
			    		$res=Db::name('xin_wen')->getLastInsID();;
                        $res=['ok'=>1,'ms'=>'成功','name'=>$res];
			    	}else{
			    		 $res=['ok'=>0,'ms'=>'失败，请联系管理员','name'=>$res];
			    	}
			    	echo json_encode($res); 
	    	}else{
	    		$this->error('更新失败'); //失败
	    	}

    	}else{
    		$lei=Db::table('xin_lei')->select(); 
       		return $this->fetch('index/news_add',['xinlei'=>$lei]);
    	}
        
    }
    //智联
    public function cai_zhi(){
          $con=$this->sendurl("https://www.zhaopin.com/");
          echo $con;
      }
    //boss直聘
    public function cai_boss(){
          $con=$this->sendurl("https://www.zhipin.com/");
          echo $con;
      }
    //幕课
    public function cai_ying(){
          $con=$this->sendurl("https://www.imooc.com/");
          echo $con;
      }
    //sf.gg论坛
    public function cai_css(){
          $con=$this->sendurl("https://segmentfault.com/");
          echo $con;
      }
    //采集
    public function news_cai(){
          return $this->fetch('index/cai');
      }
     //CURL采集
    public function sendurl($sendurl){
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL,$sendurl);
          curl_setopt($ch, CURLOPT_HEADER,0);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);//关闭https证书
          $arrData = curl_exec($ch);
          return $arrData;
        }

    //函数    
    public function cai($url){
      $con=file_get_contents($url);
      return $con;
    }
    
    public function tu(){
        $file = request()->file('file_name');
        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
        $path = DS . 'uploads' . DS . $info->getSaveName();//路径
        // echo "<pre>";
        //     print_r($file);die;
        //echo  json_encode($path);
        return $path;
    }

     /*-----新闻分类添加---------*/
    public function cate_add()
    {
    	if(request()->isPost()){ 
            $us=input('news_title');
            $data=isset($us)?$us:'';
            if(empty($data)){
               $res=['ok'=>0,'ms'=>'数据不能为空'];
               echo json_encode($res); die;
            }
            $data=['news_title'=>$data];
            $res=Db::name('xin_lei')->insert($data);
                if($res){
                        $res=Db::name('xin_lei')->getLastInsID();;
                        $res=['ok'=>1,'ms'=>'成功','name'=>$res];
                    }else{
                        $res=['ok'=>0,'ms'=>'失败，请联系管理员','name'=>$res];
                    }
               echo json_encode($res);      
             }else{
             	return $this->fetch('index/cate_add');
             }
    }
  // const succcess_code = 0; //全局状态  
// const error_code = 1;
// array_column   取某一列
// array_flip  值变键
// array_keys 取出键值
// & 取地址符
// 拼数据
// self::error_code //调用
  public function news_list(){
        $lei=Db::table('xin_lei')->select();
        $a = array_keys(array_flip(array_column($lei,'id')));//取出某一列 值变键 键值唯一的 取出键值
       
        foreach ($lei as $key => $v) {
          $lei[$key]['kai']=$lei[$v['id']['news_title']];
        }
        // $b=array_column($lei,'news_title',$a);
        // foreach ($wen as $key => $v) {
        //   $wen[$key]['cate_id']=$a;
        //    $wen[$key]['zhi']=$v[''];
        // }
         // $wen=Db::table('xin_wen')->where('cate_id',$v['id'])->select();

        echo "<pre>";
        print_r($lei);die;
      
        //return $this->fetch('index/news_list',['lei'=>$lei]);
  }
    


}