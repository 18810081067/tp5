<?php
namespace app\admin\controller;
use think\Controller;
use think\Model;
use think\Db;
header("Content-type:text/html;charset=UTF-8");
class Admin extends Controller
{

/*
*@作者 郝龙祥 
*@内容 新闻模板
*@参数 后台 模板
*@时间 2018-5-8
*/ 
    /*-----后台首页---------*/
    public function index()
    {
        return $this->fetch('index/admin');
    }

    /*-----后台top---------*/
    public function top()
    {
        return $this->fetch('index/top');
    }

    /*-----后台left----------*/
    public function left()
    {
        return $this->fetch('index/left');
    } 


}